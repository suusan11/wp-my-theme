<?php
/**
 * Created by PhpStorm.
 * User: miiiiiiiiiiie
 * Date: 2019-02-21
 * Time: 16:34
 */
?>
    <?php wp_footer(); ?>
</body>
</html>